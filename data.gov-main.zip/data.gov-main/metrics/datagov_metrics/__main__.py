from datagov_metrics import ckan, ga

ga.main()
ckan.main()

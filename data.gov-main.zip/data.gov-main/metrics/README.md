# datagov-metrics

A python module to fetch metrics from various sources (GA & CKAN) and push them to S3

Reports are then available at the path:

https://s3-us-gov-west-1.amazonaws.com/cg-baa85e06-1bdd-4672-9e3a-36333c05c6ce/{file_name}

Ex.
https://s3-us-gov-west-1.amazonaws.com/cg-baa85e06-1bdd-4672-9e3a-36333c05c6ce/global__datasets_per_org.csv

